# Welcome to your new Koding workspace

This workspace, which lives inside the 'Workspaces' folder of your
home directory, is the place where you can store all relevant and
related files to this project.

Workspaces help keep your projects organized. You can create any
number of sub-folders within this workspace in order to further
organize your work.

As you move back and forth between your workspaces, Koding will try
and remember everything about each workspace. This includes things
like IDE settings, files open, Terminals open, etc.

You can create as many new workspaces as you need on your VM.

Enjoy and Happy Koding!